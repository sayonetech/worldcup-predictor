// types/consumer.test-d.ts — a tiny TS consumer that proves types/index.d.ts mirrors
// the runtime API (PKG-02 / D-09). `tsc --noEmit` compiles this; it never runs.
// It must exercise: mountGoatGame(...) -> handle, handle.update(...), handle.destroy(),
// and reading result.timestamp AS A STRING (the Pitfall-4 drift guard).
import { mountGoatGame, paceDistance } from './index.js';
import type { GoatConfig, GoatResult, GoatGameHandle, GoatPlayer, GoatLeaderboardEntry, GoatCoinLeaderboardEntry } from './index.js';

declare const container: HTMLElement;

const player: GoatPlayer = { id: 'user-123', name: 'Mithin' };
const leaderboard: GoatLeaderboardEntry[] = [
  { name: 'Ronaldo', team: 'POR', distance: 4200 },
  { name: 'Anon', distance: 100 }   // team optional
];

const config: GoatConfig = {
  player,
  leaderboard,
  onGameEnd(result: GoatResult) {
    // timestamp MUST be a string (NOT a Date) — these string ops must type-check.
    const iso: string = result.timestamp;
    iso.toUpperCase();
    // distance is a number; id is opaque.
    const meters: number = result.distance;
    void meters;
    void result.id;
    // coins is a number (COIN-03) — the host pools it: pool += result.coins.
    const runCoins: number = result.coins;
    void runCoins;
    // durationMs is a number (AC-04) — active sim-time the server reproduces.
    const ms: number = result.durationMs;
    void ms;
    // runToken is an optional string (AC-03) — present iff a token was current at run end.
    const token: string | undefined = result.runToken;
    void token;
  }
};

const handle: GoatGameHandle = mountGoatGame(container, config);
handle.setLeaderboard(leaderboard);            // board-only refresh (the post-run call)
handle.setPlayer({ id: 'user-123', name: 'Mithin' });
handle.update({ leaderboard: [], onGameEnd: config.onGameEnd });
handle.destroy();

// ── audio config (optional) — exercise all three accepted forms so the type
// mirrors validateConfig's runtime normalization exactly (omitted / boolean / object).
const audioOmitted: GoatConfig = { onGameEnd: config.onGameEnd };                       // omitted → ON by default
const audioBool: GoatConfig = { onGameEnd: config.onGameEnd, audio: false };            // host force-mute
const audioObj: GoatConfig = { onGameEnd: config.onGameEnd, audio: { enabled: true, volume: 0.4 } };
const audioPartial: GoatConfig = { onGameEnd: config.onGameEnd, audio: { volume: 1 } }; // enabled defaults to true
mountGoatGame(container, audioOmitted).destroy();
mountGoatGame(container, audioBool).destroy();
mountGoatGame(container, audioObj).destroy();
mountGoatGame(container, audioPartial).destroy();

// ── milestones config (optional) — exercise omitted (defaults) + a valid override
// so the type mirrors validateConfig's normalizeMilestones contract (F2 / MILE-04).
const milestonesOmitted: GoatConfig = { onGameEnd: config.onGameEnd };                    // omitted → baked-in defaults
const milestonesOverride: GoatConfig = {
  onGameEnd: config.onGameEnd,
  milestones: [{ distance: 1000, label: 'Round of 16' }]                                  // host override (text-only label)
};
mountGoatGame(container, milestonesOmitted).destroy();
mountGoatGame(container, milestonesOverride).destroy();

// ── coin pool (optional inbound player.coins) — exercise the optional lifetime-pool
// total so the type mirrors validateConfig's normalizeCoins contract (COIN-04).
const playerWithPool: GoatPlayer = { id: 'user-123', name: 'Renjith', coins: 150 };
const coinsConfig: GoatConfig = { player: playerWithPool, onGameEnd: config.onGameEnd };
mountGoatGame(container, coinsConfig).destroy();
const coinsOmitted: GoatConfig = { player: { name: 'NoPool' }, onGameEnd: config.onGameEnd }; // coins optional
mountGoatGame(container, coinsOmitted).destroy();

// ── coins leaderboard (optional engagement board) + setCoinLeaderboard handle (COINLB).
const coinBoard: GoatCoinLeaderboardEntry[] = [
  { name: 'Renjith', team: 'Portugal', coins: 162 },
  { name: 'Anon', coins: 40 }   // team optional
];
const coinLbConfig: GoatConfig = { player: playerWithPool, coinLeaderboard: coinBoard, onGameEnd: config.onGameEnd };
const coinHandle: GoatGameHandle = mountGoatGame(container, coinLbConfig);
coinHandle.setCoinLeaderboard(coinBoard);   // live refresh (mirrors setLeaderboard)
coinHandle.destroy();

// ── anti-cheat (AC-01/02/05) — runToken config + setRunToken handle + paceDistance export.
const acConfig: GoatConfig = { player, leaderboard, runToken: 'tok.signed.single-use', onGameEnd: config.onGameEnd };
const acHandle: GoatGameHandle = mountGoatGame(container, acConfig);
acHandle.setRunToken('tok.next.single-use');   // arm the next run (between-runs setter)
acHandle.destroy();
const acOmitted: GoatConfig = { onGameEnd: config.onGameEnd };   // runToken optional
mountGoatGame(container, acOmitted).destroy();
// paceDistance: number -> number (the server's pace-check reproduction).
const expectedDist: number = paceDistance(16650);
void expectedDist;
