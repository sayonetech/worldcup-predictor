# Chased by the GOAT

An embeddable, framework-agnostic canvas game. A single host call —
`mountGoatGame(container, config)` — drops the full game (a Chrome-dino-style
endless runner with a "Hall of the Chased" leaderboard) into any DOM element and
reports the final result back once per run for the host to persist.

The built artifact is a **single self-contained ES module**: all CSS, the real
Saira / Saira Condensed fonts (base64-inlined), and every image ship inside one
`.mjs` with **zero runtime dependencies and zero network calls**.

> **Embedding it in a host app? Read [INTEGRATION.md](./INTEGRATION.md)** — the full
> guide: config reference, the React / SayScore example, sizing & responsiveness,
> lifecycle, and behaviour. This README is the quick reference.

## Install

This package is ESM-only and not (yet) published to a registry. Consume it from a
local checkout or a built tarball.

```bash
# from a local checkout (npm or pnpm — either works):
npm install /path/to/goat-game
# or
pnpm add /path/to/goat-game

# or pack a tarball and install that:
npm pack            # → chased-by-the-goat-1.0.0.tgz
npm install ./chased-by-the-goat-1.0.0.tgz
```

The published `files` are `dist/` (the single `.mjs`), `types/` (the hand-written
`.d.ts`), and this README. There is **no CJS/UMD build** — import it as ESM.

## Build

```bash
pnpm install        # (or: npm install)
pnpm build          # vite build → dist/chased-by-the-goat.mjs, then asserts the dist shape
```

`pnpm build` runs the Vite library build and then `scripts/assert-dist.mjs`, which
fails the build on any stray `.css`/asset file, a bare asset URL, or a network
reference — guaranteeing the single-file, fully-inlined, offline contract.

Other scripts:

```bash
pnpm dev            # dev page (index.html) — loads a single live game from source
pnpm test           # vitest unit + integration suite
pnpm typecheck      # tsc --noEmit — checks types/index.d.ts against a TS consumer
pnpm extract-fonts  # regenerate src/assets/fonts.data.js from the legacy manifest
```

## Usage

```js
import { mountGoatGame } from 'chased-by-the-goat';

const handle = mountGoatGame(document.getElementById('game'), {
  player: { id: 'user-123', name: 'Mithin' },
  leaderboard: [
    // team = country name (flags hardcoded for the 8 World Cup teams:
    // Argentina, Brasil, Germany, Netharland, Spain, Portugal, France, Belgium)
    { name: 'Ronaldo', team: 'Portugal', distance: 4200 },
    { name: 'Messi', team: 'Argentina', distance: 3980 }
  ],
  // REQUIRED — fires exactly once per run with the final result.
  onGameEnd(result) {
    // result = { id, name, distance, timestamp }
    // timestamp is an ISO-8601 STRING (not a Date).
    saveScore(result);
  }
});
```

### Refreshing the leaderboard between runs

The game changes the standings every run. Persist the score, re-fetch the board, then
push it back with **`handle.setLeaderboard(leaderboard)`** — it keeps the current player,
clones your array, and re-renders the board in place. It **never** interrupts an active
run, replays the intro, or fires `onGameEnd`.

```js
const game = mountGoatGame(el, {
  player, leaderboard: await api.getLeaderboard(),
  async onGameEnd(result) {
    await api.saveScore(result);                 // persist
    game.setLeaderboard(await api.getLeaderboard()); // re-fetch + refresh in place
  },
});
```

`handle.setPlayer(player)` refreshes just the player. `handle.update(config)` replaces
both from a full config (omitting `player` resets the name to `"Player"` — prefer
`setLeaderboard` for a board-only refresh). Full guide: [INTEGRATION.md](./INTEGRATION.md).

### Teardown

Call `handle.destroy()` to unmount: it removes the canvas, all listeners, the rAF
loop, the ResizeObserver, and the registered fonts, leaving the container empty.

### React

Mount in an effect and **always** return `destroy` as the cleanup so React unmount
(and Strict-Mode double-invoke in dev) never leaks a game instance:

```jsx
import { useEffect, useRef } from 'react';
import { mountGoatGame } from 'chased-by-the-goat';

function GoatGame({ player, leaderboard, onGameEnd }) {
  const ref = useRef(null);

  useEffect(() => {
    const handle = mountGoatGame(ref.current, { player, leaderboard, onGameEnd });
    return () => handle.destroy();   // cleanup on unmount / before re-run
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <div ref={ref} style={{ width: '100%' }} />;
}
```

To push a refreshed leaderboard without remounting, keep the `handle` in a ref and
call `handle.update(...)` from a separate effect instead of re-running the mount.

## API

| Export | Signature | Notes |
| ------ | --------- | ----- |
| `mountGoatGame` | `(container: HTMLElement, config: GoatConfig) => GoatGameHandle` | Throws if `container` is not a DOM element or `onGameEnd` is not a function. |
| `handle.setLeaderboard` | `(leaderboard: GoatLeaderboardEntry[]) => void` | **Refresh only the leaderboard** (keeps the player); re-renders in place. The post-run refresh call. |
| `handle.setPlayer` | `(player: GoatPlayer) => void` | Refresh only the player `{id,name}` (keeps the leaderboard). |
| `handle.update` | `(config: GoatConfig) => void` | Refresh both from a full config; never interrupts a run. |
| `handle.destroy` | `() => void` | Full teardown; container left empty. |

`GoatResult` (passed to `onGameEnd`): `{ id, name, distance, timestamp }` where
`timestamp` is an **ISO-8601 string**. Full types in [`types/index.d.ts`](./types/index.d.ts).

## Artifact size (by design)

The bundle is intentionally large — roughly **560 KB** raw (~400 KB gzipped). The
bulk is the real Saira / Saira Condensed `woff2` faces, base64-inlined so the game
renders **pixel-faithful to the original with no font CDN, no extra requests, and no
FOUT** (first paint is gated on `document.fonts.ready`). This is a deliberate
single-file, fully-offline trade-off: one import, zero network, exact fidelity.
